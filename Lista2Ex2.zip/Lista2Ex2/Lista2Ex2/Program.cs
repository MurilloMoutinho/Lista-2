﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a;
            double b;
            Console.WriteLine("Digite o primeiro valor");
            a = double.Parse(Console.ReadLine());
            Console.WriteLine("Digite o segundo valor");
            b = double.Parse(Console.ReadLine());

            if (a == b)
                Console.WriteLine("Igual");
            else
            if (a > b)
                Console.WriteLine("1° valor é o maior");
            else
                Console.WriteLine("2° valor é maior");
        }
    }
}
